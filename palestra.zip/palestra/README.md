# palestra

A Pen created on CodePen.

Original URL: [https://codepen.io/Dielle-Di/pen/LEVPgbv](https://codepen.io/Dielle-Di/pen/LEVPgbv).

minha lista de exercicios
