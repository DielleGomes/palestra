function mostrarTreino(diaSelecionado) {
  const treinos = document.querySelectorAll('.treino-dia');
  treinos.forEach(treino => treino.style.display = 'none');

  const dia = document.getElementById(diaSelecionado);
  if (dia) dia.style.display = 'block';
}